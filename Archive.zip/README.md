# Action Organizing Mapping Tool

![Alt text](screen.png?raw=true "Direct Action Organizing Map")

Demo can be found [here](https://s3.us-east-2.amazonaws.com/resistancemap/maptest/index.html "Title").
